// src/words.js

const words = [
  'javascript',
  'react',
  'hangman',
  'coding',
  'program',
  // ...add more words
];

export default words;

