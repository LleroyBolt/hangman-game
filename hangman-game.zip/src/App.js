// src/App.js

import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import HangmanDrawing from './components/HangmanDrawing';
import Word from './components/Word';
import Keyboard from './components/Keyboard';
import HelpModal from './components/HelpModal';
import RestartButton from './components/RestartButton';
import words from './words';
import './App.css';

function App() {
  // Here are the state variables
  const [word, setWord] = useState('');
  const [guessedLetters, setGuessedLetters] = useState([]);
  const [wrongGuesses, setWrongGuesses] = useState(0);
  const [gameStatus, setGameStatus] = useState('playing'); // 'playing', 'won', 'lost'
  const [showHelp, setShowHelp] = useState(false);

  // Here we initialize the game
  useEffect(() => {
    startGame();
  }, []);

  // This is the function used to start or restart the game
  const startGame = () => {
    const randomWord = words[Math.floor(Math.random() * words.length)];
    setWord(randomWord);
    setGuessedLetters([]);
    setWrongGuesses(0);
    setGameStatus('playing');
  };

  // Here we handle letter guess
  const handleGuess = (letter) => {
    if (gameStatus !== 'playing') return;

    if (guessedLetters.includes(letter)) return;

    setGuessedLetters((prevLetters) => [...prevLetters, letter]);

    if (!word.includes(letter)) {
      setWrongGuesses((prevWrongGuesses) => prevWrongGuesses + 1);
    }
  };

  // Here we check for a win or loss
  useEffect(() => {
    const isWinner = word.split('').every((letter) => guessedLetters.includes(letter));
    if (isWinner) {
      setGameStatus('won');
    } else if (wrongGuesses >= 6) {
      setGameStatus('lost');
    }
  }, [guessedLetters, wrongGuesses, word]);

  return (
    <div className="App">
      <Header onHelp={() => setShowHelp(true)} />
      <HangmanDrawing wrongGuesses={wrongGuesses} />
      <Word word={word} guessedLetters={guessedLetters} />
      <Keyboard onGuess={handleGuess} guessedLetters={guessedLetters} />
      <RestartButton onRestart={startGame} />

      {gameStatus === 'won' && <p className="status-message">You Won!</p>}
      {gameStatus === 'lost' && (
        <p className="status-message">
          You Lost! The word was: <strong>{word}</strong>
        </p>
      )}

      {showHelp && <HelpModal onClose={() => setShowHelp(false)} />}
    </div>
  );
}

export default App;
