// src/components/HangmanDrawing.js

import React from 'react';

// Here is the HangmanDrawing component displaying the hangman image
function HangmanDrawing() {
  // Here I set the image URL
  const imageUrl = "https://i292.photobucket.com/albums/mm31/Final_Destination_2/hangman-1.png";

  return (
    <div className="hangman-drawing">
      <img src={imageUrl} alt="Hangman" />
    </div>
  );
}

export default HangmanDrawing;
