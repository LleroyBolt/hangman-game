// src/components/Keyboard.js

import React from 'react';

// Here is the Keyboard component where users can make guesses
function Keyboard({ onGuess, guessedLetters }) {
  // Here I define all letters of the alphabet
  const letters = 'abcdefghijklmnopqrstuvwxyz'.split('');

  return (
    <div className="keyboard">
      {letters.map((letter) => (
        <button
          key={letter}
          onClick={() => onGuess(letter)}
          disabled={guessedLetters.includes(letter)}
          className="key-button"
        >
          {letter}
        </button>
      ))}
    </div>
  );
}

export default Keyboard;
