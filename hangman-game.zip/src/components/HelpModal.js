// src/components/HelpModal.js

import React from 'react';

// Here is the HelpModal component with close functionality
function HelpModal({ onClose }) {
  return (
    <div className="modal-overlay">
      <div className="help-modal">
        <h2>How to Play</h2>
        <p>
          Guess the word by selecting letters. Each incorrect guess brings the hangman closer to being hanged.
          You have 6 incorrect guesses before the game is over.
        </p>
        <button onClick={onClose} className="close-button">
          Close
        </button>
      </div>
    </div>
  );
}

export default HelpModal;
