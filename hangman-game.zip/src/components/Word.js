// src/components/Word.js

import React from 'react';

// Here is the Word component showing the word to be guessed
function Word({ word, guessedLetters }) {
  return (
    <div className="word">
      {word.split('').map((letter, index) => (
        <span className="letter" key={index}>
          {guessedLetters.includes(letter) ? letter : '_'}
        </span>
      ))}
    </div>
  );
}

export default Word;
