// src/components/Header.js

import React from 'react';

// Here is the Header component including the help button
function Header({ onHelp }) {
  return (
    <header className="header">
      <h1>Hangman Game</h1>
      <button className="help-button" onClick={onHelp}>
        Help
      </button>
    </header>
  );
}

export default Header;
